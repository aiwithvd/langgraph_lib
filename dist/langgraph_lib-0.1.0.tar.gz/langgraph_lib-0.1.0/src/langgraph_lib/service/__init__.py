# src/langgraph_fastapi/service/__init__.py

from .service import create_app

__all__ = ["create_app"]
